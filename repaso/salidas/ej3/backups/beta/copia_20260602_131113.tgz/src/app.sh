#!/bin/bash
echo beta