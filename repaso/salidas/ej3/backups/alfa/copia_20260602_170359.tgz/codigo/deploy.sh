#!/bin/bash
echo alfa